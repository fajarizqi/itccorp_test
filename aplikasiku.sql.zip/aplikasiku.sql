-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Apr 2020 pada 12.20
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aplikasiku`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `event`
--

CREATE TABLE `event` (
  `id_event` int(11) NOT NULL,
  `judul_event` varchar(150) NOT NULL,
  `tgl_acara` date NOT NULL,
  `waktu_acara` time NOT NULL,
  `nama_tempat` varchar(250) NOT NULL,
  `status_event` enum('LIVE','DRAFT') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `event`
--

INSERT INTO `event` (`id_event`, `judul_event`, `tgl_acara`, `waktu_acara`, `nama_tempat`, `status_event`) VALUES
(1, 'Event A', '2020-05-31', '15:00:00', 'Lapangan A', 'LIVE'),
(2, 'Event B', '2020-05-22', '10:00:00', 'Aula B', 'LIVE'),
(3, 'Event C', '2020-06-03', '19:00:00', 'Lapangan C', 'DRAFT'),
(4, 'Event D', '2020-05-29', '20:00:00', 'Hall D', 'LIVE');

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `event_view`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `event_view` (
`id_event` int(11)
,`waktu_acara` time
,`tgl_acara` date
,`nama_tempat` varchar(250)
,`judul_event` varchar(150)
,`kuota_online` decimal(32,0)
,`kuota_offline` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pregenerate_barcode`
--

CREATE TABLE `pregenerate_barcode` (
  `id_pregenerate` int(11) NOT NULL,
  `id_event` int(11) NOT NULL,
  `id_tiket` int(11) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pregenerate_barcode`
--

INSERT INTO `pregenerate_barcode` (`id_pregenerate`, `id_event`, `id_tiket`, `barcode`, `status`) VALUES
(1, 1, 1, 'ADS12344', 0),
(2, 1, 1, 'ADS23412', 0),
(3, 1, 1, 'ADS45364', 0),
(4, 1, 1, 'ADS34253', 0),
(5, 1, 1, 'ADS23124', 0),
(6, 1, 1, 'ADS56473', 0),
(7, 1, 2, 'VC34567', 0),
(8, 1, 2, 'VC12789', 0),
(9, 1, 2, 'VC23567', 0),
(10, 1, 2, 'VC56374', 0),
(11, 1, 2, 'VC64578', 0),
(12, 1, 2, 'VC09389', 0),
(13, 1, 2, 'VC34567', 0),
(14, 1, 2, 'VC23784', 0),
(15, 3, 5, 'AD89347', 0),
(16, 3, 5, 'AD09948', 0),
(17, 3, 5, 'AD09478', 0),
(18, 4, 6, 'EE87467', 0),
(19, 4, 6, 'EE37802', 0),
(20, 4, 6, 'EE35648', 0),
(21, 4, 6, 'EE88493', 0),
(22, 4, 6, 'EE78290', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tiket`
--

CREATE TABLE `tiket` (
  `id_tiket` int(11) NOT NULL,
  `id_event` int(11) NOT NULL,
  `nama_tiket` varchar(100) NOT NULL,
  `harga_tiket` int(11) NOT NULL,
  `kuota_online` int(11) NOT NULL,
  `kuota_offline` int(11) NOT NULL,
  `tgl_mulai_penjualan` date NOT NULL,
  `tgl_akhir_penjualan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tiket`
--

INSERT INTO `tiket` (`id_tiket`, `id_event`, `nama_tiket`, `harga_tiket`, `kuota_online`, `kuota_offline`, `tgl_mulai_penjualan`, `tgl_akhir_penjualan`) VALUES
(1, 1, 'VIP', 150000, 20, 25, '2020-04-27', '2020-05-15'),
(2, 1, 'Ekonomi', 100000, 50, 60, '2020-04-27', '2020-05-15'),
(3, 2, 'Class A', 250000, 15, 25, '2020-04-28', '2020-05-07'),
(4, 2, 'Class B', 240000, 25, 25, '2020-04-28', '2020-05-07'),
(5, 3, 'Tribun', 15000, 15, 25, '2020-04-28', '2020-05-28'),
(6, 4, 'Festival', 250000, 25, 60, '2020-04-28', '2020-05-22');

-- --------------------------------------------------------

--
-- Struktur untuk view `event_view`
--
DROP TABLE IF EXISTS `event_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `event_view`  AS  select `event`.`id_event` AS `id_event`,`event`.`waktu_acara` AS `waktu_acara`,`event`.`tgl_acara` AS `tgl_acara`,`event`.`nama_tempat` AS `nama_tempat`,`event`.`judul_event` AS `judul_event`,sum(`tiket`.`kuota_online`) AS `kuota_online`,sum(`tiket`.`kuota_offline`) AS `kuota_offline` from (`tiket` left join `event` on((`event`.`id_event` = `tiket`.`id_event`))) where (`event`.`status_event` = 'LIVE') group by `event`.`id_event` ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id_event`);

--
-- Indeks untuk tabel `pregenerate_barcode`
--
ALTER TABLE `pregenerate_barcode`
  ADD PRIMARY KEY (`id_pregenerate`);

--
-- Indeks untuk tabel `tiket`
--
ALTER TABLE `tiket`
  ADD PRIMARY KEY (`id_tiket`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `event`
--
ALTER TABLE `event`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pregenerate_barcode`
--
ALTER TABLE `pregenerate_barcode`
  MODIFY `id_pregenerate` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT untuk tabel `tiket`
--
ALTER TABLE `tiket`
  MODIFY `id_tiket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
